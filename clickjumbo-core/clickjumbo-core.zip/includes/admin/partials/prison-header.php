<?php
function render_prison_panel_header()
{
    echo '<div class="wrap">
        <h1>Gerenciar Penitenciárias</h1>
        <p>
            <a href="#" id="btn-ver-lista" class="button button-secondary">Ver todas</a>
            <a href="#" id="btn-cadastrar-nova" class="button button-primary">Cadastrar nova</a>
        </p>';
}
