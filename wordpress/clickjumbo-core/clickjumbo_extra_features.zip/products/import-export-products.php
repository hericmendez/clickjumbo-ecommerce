<?php
if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
    register_rest_route('clickjumbo/v1', '/export-products', [
        'methods' => 'GET',
        'callback' => 'clickjumbo_export_products',
        'permission_callback' => '__return_true',
    ]);
});

function clickjumbo_export_products() {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="produtos.csv"');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Nome', 'Peso', 'Preço', 'Penitenciária']);

    $products = wc_get_products(['limit' => -1]);
    foreach ($products as $product) {
        fputcsv($output, [
            $product->get_id(),
            $product->get_name(),
            $product->get_weight(),
            $product->get_price(),
            $product->get_meta('prison')
        ]);
    }

    fclose($output);
    exit;
}
